#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_STUDS 10

struct student{
  char name[100];
  int age;
};

struct student class [] = {
  "Giorgi", 42,
  "Bondo", 23,
  "Gela", 24,
  "Joni", 35,
  "Petre", 20,
  "Mzevinari", 30,
  "Severiane", 19,
  "Mtvarisa", 32,
  "Soso", 37,
  "Bikenti", 51
};

void apply(struct student * student_array, int n, void (*func)(void *prec, void *arg), void *arg){
  int i;
  for (i=0; i<n; i++){
    func(&student_array[i], arg);
  }
}

void print_student(struct student *pstud){
  printf("%s %d\n", pstud->name, pstud->age);
}

void print_record(void *prec, void *arg){
  struct student *pstud = (struct student *)prec;
  print_student(pstud);
}


int cmpForNames(const void* a,const  void* b){
	
	struct student A = *(struct student*)a;
	struct student B = *(struct student*)b;

	return strcmp(A.name, B.name);
}

int cmpForAges(const void* a,const  void* b){
	
	struct student A = *(struct student*)a;
	struct student B = *(struct student*)b;
	
	if (A.age > B.age) return 1;
	if (A.age < B.age) return -1;
	return 0;
}
void sort_by_name(struct student class[], int n){
	
	qsort(class,  (size_t)n, sizeof(struct student), cmpForNames);

}

void sort_by_age(struct student class[], int n){
	qsort(class,  (size_t)n, sizeof (struct student), cmpForAges);
}

void isolder(void *prec, void *arg){
  struct student A = *(struct student*)prec;
  if (A.age > *(int*) arg)
	  printf("%s\n",A.name);
}

int main(){
  
  int n = sizeof(class) / sizeof(struct student); //student count
	
  printf("Raw records\n");
  printf("------------------\n");
  apply(class, n, print_record, NULL);
  printf("\n\n");

  printf("Sorted by name\n");
  printf("------------------\n");
  sort_by_name(class, n);
  apply(class, n, print_record, NULL);
  printf("\n\n");


  printf("Sorted by age\n");
  printf("------------------\n");
  sort_by_age(class, n);
  apply(class, n, print_record, NULL);
  printf("\n\n");

  printf("Students older than 30\n");
  printf("------------------\n");
  int age = 30;
  apply(class, n, isolder, &age);
  printf("\n\n");

  return 0;
}
