#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <semaphore.h>
#include <pthread.h>


typedef struct Node {
	int value;
	struct Node * next;
	sem_t nodeFree;
} Node;


typedef struct {
	Node * start;
	int size;
	
	//cx
	sem_t touchSem;
	sem_t orderSem;

} Circle;


void CircleInit(Circle * c);
void CircleInsert(Circle * c, int index, int value);
int CircleGetNth(Circle * c, int index);
int CircleSize(Circle * c);
static Node * GetNthPointer(Circle *c, int n);


