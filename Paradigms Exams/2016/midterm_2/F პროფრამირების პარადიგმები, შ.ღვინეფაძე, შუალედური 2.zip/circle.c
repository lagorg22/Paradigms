﻿#include "circle.h"


void CircleInit(Circle * c) {
	
	//cx	
	sem_init(&(c->touchSem), 0, 1);
	sem_init(&(c->orderSem), 0, 1);

	c->start = NULL;
	c->size = 0;
}

void CircleInsert(Circle * c, int index, int value) {
	assert(index >= 0);


	Node * tmp = (Node *)malloc(sizeof(Node));
	tmp->value = value;

	//cx
	//ეს სემაფორა აღნიშნავს გამოიყენება თუ არა ეს წიბა ამ მომენტში რამეში(ამის მარჯვნივ ან მარცხნივ რამე ემატება თუ არა)
	sem_init(&(tmp->nodeFree), 0, 1);

	
	//cx
	//ეს საჭიროა იმისთვის, რომ მხოლოდ პირველმა სრედმა შეასრულოს 
	//ის, რაც if-ში წერია, დანარჩენებმა else-ში რაც წერია
	sem_wait(&(c->orderSem));

	if (c->size == 0) {
		c->start = tmp;
		tmp->next = tmp;		
		
	} else {
		
		//ეს საჭიროა რათა პირველი სრედის გარდა დანარჩენებს არ მოუწიოთ ამ სემაფორისთვის ლოდინი
		sem_post(&(c->orderSem));

		index = index % c->size;
	
		Node * before = GetNthPointer(c, index - 1);
		
		//cx
		//locking semaphores of affected nodes, odd first
		if (index %2 == 0){
			sem_wait(&( before -> nodeFree ));
			sem_wait(&( before -> next -> nodeFree ));
		} else{
			sem_wait(&( before -> next -> nodeFree ));
			sem_wait(&( before -> nodeFree ));
		}

		sem_post(&(c->touchSem));
		
		tmp->next = before->next;
		before->next = tmp;
		
		int av = (before->value + before->next->value + before->next->next->value) / 3;
		
		before->value = av;
		before->next->value = av;
		before->next->next->value = av;
		
		if (index == 0) {
			c->start = tmp;
		}

		//cx
		//unlocking semaphores(any order)
		sem_post(&( before -> nodeFree ));
		sem_post(&( before -> next -> nodeFree ));
	}
	
	//ორმა სრედმა ერთდროულად რომ არ სცადონ с-სგაზრდა
	sem_wait(&c->touchSem));
	c->size++;
	sem_post(&c->touchSem));

	//ეს საჭიროა რათა პირველი სრედის გარდა დანარჩენებს არ მოუწიოთ ამ სემაფორისთვის ლოდინი
	sem_post(&(c->orderSem));
}

int CircleGetNth(Circle * c, int index) {
	assert(index >= 0 && c->size > 0);
	
	index = index % c->size;
	return GetNthPointer(c, index)->value;
}

int CircleSize(Circle * c) {
	return c->size;
}

static Node * GetNthPointer(Circle *c, int n) {
	assert( c->start != NULL );
	
	if (n == -1)
		n = c->size-1; 

	Node * curr = c->start;
	for (int i=0; i<n; i++) {
		curr = curr->next;
	}
	
	
	return curr;
}


